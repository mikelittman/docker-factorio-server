data:extend
({
  {
    type = "technology",
    name = "worker-robots-storage-4",
    icon = "__InfiniteWorkerRobotCapacity_Research__/worker-robots-storage.png",
    icon_size = 128,
    prerequisites = {"worker-robots-storage-3"},
    effects =
    {
      {
        type = "worker-robot-storage",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "((2.5^(L-3))+4)*100",
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        {"high-tech-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 30
    },
    max_level = "infinite",
    upgrade = true,
    order = "c-k-f-e"
  }
})
