if not MergingChests then MergingChests = {} end

-- globaly used functions
function sortByX(entityA, entityB)
	local xResult = entityA.position.x - entityB.position.x
	if xResult == 0 then
		return entityA.position.y < entityB.position.y
	else
		return xResult < 0
	end
end

function sortByY(entityA, entityB)
	local yResult = entityA.position.y - entityB.position.y
	if yResult == 0 then
		return entityA.position.x < entityB.position.x
	else
		return yResult < 0
	end
end

function string.starts(String, Start)
   return string.sub(String, 1, string.len(Start)) == Start
end

function math.round(num) 
	if num >= 0 then
		return math.floor(num + 0.5)
	else
		return math.ceil(num - 0.5)
	end
end

function MergingChests.GetChestSize(entity)
	if entity.name == "steel-chest" then
		return 1, 1
	elseif string.starts(entity.name, "wide-chest-") then
		return tonumber(string.sub(entity.name, 12)), 1
	elseif string.starts(entity.name, "high-chest-") then
		return 1, tonumber(string.sub(entity.name, 12))
	elseif entity.name == "entity-ghost" then

		if string.starts(entity.ghost_name, "wide-chest-") then
			return tonumber(string.sub(entity.ghost_name, 12)), 1
		elseif string.starts(entity.ghost_name, "high-chest-") then
			return 1, tonumber(string.sub(entity.ghost_name, 12))
		else
			return 0, 0
		end
	else
		return 0, 0
	end
end

-- merging of chests
function MergingChests.OnPlayerSelectedArea(event)
	if event.item and event.item == "merge-chest-selector" then
		local player = game.players[event.player_index]
		if event.area.left_top.x ~= event.area.right_bottom.x and event.area.left_top.y ~= event.area.right_bottom.y then
			
			-- use event entities and remove everything but mergable chests
			local entities = event.entities
			for i = #entities, 1, -1 do
				if not (entities[i].name == "steel-chest" or string.starts(entities[i].name, "wide-chest-") or string.starts(entities[i].name, "high-chest-")) then
					table.remove(entities, i)
				end
			end

			if #entities > 1 then
				MergingChests.PerformMerging(entities, player)
			end
		end
	end
end

function MergingChests.PerformMerging(entities, player)
    -- find bounding box
    local width, height = MergingChests.FindBoundingBoxSize(entities)
 
    if width ~= height then
        local mergeHorizontaly = width > height
 
        local entityGroups = MergingChests.SortIntoGroups(entities, mergeHorizontaly)
        for _, group in ipairs(entityGroups) do
            -- calculate new chest size
            local size = 0
            for j = 1, #group do
                size = size + math.max(MergingChests.GetChestSize(group[j]))
            end
 
            if mergeHorizontaly then
                MergingChests.MergeHorizontal(group, player, size)
            else
                MergingChests.MergeVertical(group, player, size)
            end
        end
    else
        player.print({"mod-messages.selected-width-and-height-equal"})
    end
end

function MergingChests.FindBoundingBoxSize(entities)
	local width, height = MergingChests.GetChestSize(entities[1])
	local min = entities[1].position
	local max = entities[1].position
	min.x = min.x - width / 2
	min.y = min.y - height / 2
	max.x = max.x + width / 2
	max.y = max.y + height / 2

	for i = 2, #entities do
		width, height = MergingChests.GetChestSize(entities[i])
		local offsetX = width / 2
		local offsetY = height / 2

		if min.x > entities[i].position.x - offsetX then min.x = entities[i].position.x - offsetX end
		if min.y > entities[i].position.y - offsetY then min.y = entities[i].position.y - offsetY end
		if max.x < entities[i].position.x + offsetX then max.x = entities[i].position.x + offsetX end
		if max.y < entities[i].position.y + offsetY then max.y = entities[i].position.y + offsetY end
	end

	return math.round(max.x) - math.round(min.x), math.round(max.y) - math.round(min.y)
end

function MergingChests.SortIntoGroups(entities, mergeHorizontaly)
	-- remove chests in not merged direction
	for i = #entities, 1, -1 do
		local width, height = MergingChests.GetChestSize(entities[i])
		if mergeHorizontaly and height > 1 or not mergeHorizontaly and width > 1 then
			table.remove(entities, i);
		end
	end

	local result = { }
	
	if mergeHorizontaly then
		table.sort(entities, sortByY)
	else
		table.sort(entities, sortByX)
	end
	
	local width, height = MergingChests.GetChestSize(entities[1])
	local offsetX = width / 2
	local offsetY = height / 2

	local group = { entities[1] }
	local groupSize = math.max(width, height)
	-- bottom-right corner of last chest
	local lastX = entities[1].position.x + offsetX
	local lastY = entities[1].position.y + offsetY
	for i = 2, #entities do
		width, height = MergingChests.GetChestSize(entities[i])
		offsetX = width / 2
		offsetY = height / 2
		
		-- continuous horizontal or vertical line
		if  lastX + 0.1 > entities[i].position.x - offsetX and lastY > entities[i].position.y and mergeHorizontaly or
			lastY + 0.1 > entities[i].position.y - offsetY and lastX > entities[i].position.x and not mergeHorizontaly then

			-- check maximum chest size
			if groupSize + math.max(width, height) > settings.startup["max-chest-size"].value then
				if #group > 1 then
					table.insert(result, group)
				end

				group = { entities[i] }
				groupSize = math.max(width, height)
			else
				groupSize = groupSize + math.max(width, height)
				table.insert(group, entities[i])
			end
		else
			-- if there was something to merge, add group
			if #group > 1 then
				table.insert(result, group)
			end

			group = { entities[i] }
			groupSize = math.max(width, height)
		end
		
		lastX = entities[i].position.x + offsetX
		lastY = entities[i].position.y + offsetY
	end
	
	if #group > 1 then
		table.insert(result, group)
	end

	return result
end

function MergingChests.MergeHorizontal(entities, player, size)
	local firstChestSize = math.max(MergingChests.GetChestSize(entities[1]))
	local newChest = player.surface.create_entity{name = "wide-chest-"..size, position = {entities[1].position.x + size / 2 - firstChestSize / 2, entities[1].position.y}, force = player.force, player = player}

	MergingChests.MoveToInventory(entities, newChest)
end

function MergingChests.MergeVertical(entities, player, size)
	local firstChestSize = math.max(MergingChests.GetChestSize(entities[1]))
	local newChest = player.surface.create_entity{name = "high-chest-"..size, position = {entities[1].position.x, entities[1].position.y + size / 2 - firstChestSize / 2}, force = player.force, player = player}
	
	MergingChests.MoveToInventory(entities, newChest)
end

function MergingChests.MoveToInventory(fromEntities, toEntity)
	local toInventory = toEntity.get_inventory(1)
	local destinationStack = 1
	local barCount = 0

	for i, entity in ipairs(fromEntities) do
		local oldInventory = entity.get_inventory(1)
		barCount = barCount + oldInventory.getbar()
		for j = 1, #oldInventory do
			if destinationStack > #toInventory then
				break
			elseif oldInventory[j].valid_for_read then
				toInventory[destinationStack].set_stack(oldInventory[j])
				destinationStack = destinationStack + 1
			end
		end
		entity.destroy()
	end

	-- set bar after moving items
	toInventory.setbar(barCount)
end

-- splitting of chests
function MergingChests.OnPlayerAltSelectedArea(event)
	if event.item and event.item == "merge-chest-selector" then
		local player = game.players[event.player_index]
		if event.area.left_top.x ~= event.area.right_bottom.x and event.area.left_top.y ~= event.area.right_bottom.y then
			
			-- use event entities and remove everything but wide-chests and high-chests
			local entities = event.entities
			for i = #entities, 1, -1 do
				if not string.starts(entities[i].name, "wide-chest-") and not string.starts(entities[i].name, "high-chest-") then
					table.remove(entities, i)
				end
			end

			if #entities > 0 then
				for i, entity in ipairs(entities) do
					local size = math.max(MergingChests.GetChestSize(entity))

					if string.starts(entities[i].name, "wide-chest-") then
						MergingChests.SplitHorizontaly(entity, player, size)
					elseif string.starts(entities[i].name, "high-chest-") then
						MergingChests.SplitVerticaly(entity, player, size)
					end
				end
			end
		end
	end
end

function MergingChests.SplitHorizontaly(entity, player, count)
	local newEntities = { }
	for i = 1, count do
		table.insert(newEntities, player.surface.create_entity{name = "steel-chest", position = {entity.position.x - (count + 1) / 2 + i, entity.position.y}, force = player.force, player = player})
	end

	MergingChests.MoveToInventories(entity, newEntities)
end

function MergingChests.SplitVerticaly(entity, player, count)
	local newEntities = { }
	for i = 1, count do
		table.insert(newEntities, player.surface.create_entity{name = "steel-chest", position = {entity.position.x, entity.position.y - (count + 1) / 2 + i}, force = player.force, player = player})
	end

	MergingChests.MoveToInventories(entity, newEntities)
end

function MergingChests.MoveToInventories(fromEntity, toEntities)
	local oldInventory = fromEntity.get_inventory(1)
	local destinationStack = 1
	local j = 1
	local toInventory = toEntities[j].get_inventory(1)

	for i = 1, #oldInventory do
		if oldInventory[i].valid_for_read then
			toInventory[destinationStack].set_stack(oldInventory[i])
			destinationStack = destinationStack + 1
		end

		if destinationStack > #toInventory then
			j = j + 1
			if j > #toEntities then
				break
			end
			toInventory = toEntities[j].get_inventory(1)
			destinationStack = 1
		end
	end
	fromEntity.destroy()
end

-- ghost blueprinting
function MergingChests.ProcessTasksToMerge()
    if not global.tasks_to_merge then
		return
	end

    for counter = #global.tasks_to_merge, 1, -1 do
        local task = global.tasks_to_merge[counter]
        if game.tick - task.created_at > settings.startup["ghost-timeout-minutes"].value * 60 * 60 then
            table.remove(global.tasks_to_merge, counter)
        else
			local player = game.players[task.player_index]

            local entities = game.surfaces[task.surface_index].find_entities_filtered{area = task.bounding_box, name = "steel-chest", force = player.force}
            
            if #entities == task.chest_size then
				MergingChests.PerformMerging(entities, player)
                table.remove(global.tasks_to_merge, counter)
            end
        end
    end

    if #global.tasks_to_merge < 1 then
		global.tasks_to_merge = nil
	end
end

function MergingChests.OnBuilt(event)
    local player = game.players[event.player_index]
    local entity = event.created_entity
    if entity and entity.valid then
		-- when placing a ghost
		if entity.name == "entity-ghost" then
			local size = math.max(MergingChests.GetChestSize(entity))
			-- when placing a wide/high chest ghost
			if size > 1 then
				local task_to_merge = {
					surface_index = entity.surface.index,
					bounding_box  = entity.bounding_box,
					chest_size    = size,
					player_index  = event.player_index,
					created_at    = event.tick
				}

				-- place steel chest ghosts
				if string.starts(entity.ghost_name, "wide-chest-") then
					MergingChests.SplitGhostHorizontaly(entity, player, size)
				elseif string.starts(entity.ghost_name, "high-chest-") then
					MergingChests.SplitGhostVerticaly(entity, player, size)
				end

				-- destroy old ghost
				entity.destroy()

				if not global.tasks_to_merge then
					global.tasks_to_merge = { }
				end
				table.insert(global.tasks_to_merge, task_to_merge)
			end
		--elseif entity.name == "steel-chest" then
		--	MergingChests.ProcessTasksToMerge()
		end
    end
end

function MergingChests.SplitGhostHorizontaly(entity, player, count)
    for i = 1, count do
        player.surface.create_entity{name = "entity-ghost", inner_name = "steel-chest", expires = false, position = {entity.position.x - (count + 1) / 2 + i, entity.position.y}, force = player.force, player = player}
    end
end

function MergingChests.SplitGhostVerticaly(entity, player, count)
    for i = 1, count do
        player.surface.create_entity{name = "entity-ghost", inner_name = "steel-chest", expires = false, position = {entity.position.x, entity.position.y - (count + 1) / 2 + i}, force = player.force, player = player}
    end
end

script.on_event(defines.events.on_player_selected_area, MergingChests.OnPlayerSelectedArea)
script.on_event(defines.events.on_player_alt_selected_area, MergingChests.OnPlayerAltSelectedArea)
script.on_event(defines.events.on_tick, MergingChests.ProcessTasksToMerge)
script.on_event(defines.events.on_built_entity, MergingChests.OnBuilt)