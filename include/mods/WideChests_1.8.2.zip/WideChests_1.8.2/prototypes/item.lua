function MergingChests.CreateWideChestItem(width)
	local name = "wide-chest-"..width
	return
	{
		type = "item",
		name = name,
		localised_name = {"chest-name.wide-chest", width},
		icon = "__base__/graphics/icons/steel-chest.png",
		flags = {"goes-to-quickbar", "hidden"},
		subgroup = "storage",
		order = "d[items]-b[steel-chest]h"..string.format("%02d", width),
		place_result = name,
		stack_size = 10
	}
end

function MergingChests.CreateHighChestItem(height)
	local name = "high-chest-"..height
	return
	{
		type = "item",
		name = name,
		localised_name = {"chest-name.high-chest", height},
		icon = "__base__/graphics/icons/steel-chest.png",
		flags = {"goes-to-quickbar", "hidden"},
		subgroup = "storage",
		order = "d[items]-b[steel-chest]w"..string.format("%02d", height),
		place_result = name,
		stack_size = 10
	}
end

for i = 2, settings.startup["max-chest-size"].value do
	data:extend({MergingChests.CreateWideChestItem(i), MergingChests.CreateHighChestItem(i)})
end

data:extend(
{
	{
		type = "selection-tool",
		name = "merge-chest-selector",
		icon = "__WideChests__/graphics/icons/merge-chest-selector.png",
		flags = { "goes-to-quickbar" },
		subgroup = "tool",
		order = "c[automated-construction]-a[blueprint]",
		stack_size = 1,
		draw_label_for_cursor_render = true,
		selection_color = { r = 0, g = 0, b = 1 },
		alt_selection_color = { r = 1, g = 0, b = 0 },
		selection_mode = { "blueprint", "matches-force" },
		alt_selection_mode = { "blueprint", "matches-force" },
		selection_cursor_box_type = "entity",
		alt_selection_cursor_box_type = "entity"
	},
})