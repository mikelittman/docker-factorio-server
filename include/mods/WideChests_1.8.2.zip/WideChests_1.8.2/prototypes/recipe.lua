data:extend(
{
	{
		type = "recipe",
		name = "merge-chest-selector",
		energy_required = 1,
		ingredients =
		{
			{"electronic-circuit", 1}
		},
		result = "merge-chest-selector",
		enabled = false
	},
})