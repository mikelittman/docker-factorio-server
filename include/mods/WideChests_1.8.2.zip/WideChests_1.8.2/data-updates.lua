if not data.raw.technology["steel-processing"].effects then
	data.raw.technology["steel-processing"].effects = {}
end

table.insert(data.raw.technology["steel-processing"].effects, {type="unlock-recipe", recipe = "merge-chest-selector"})