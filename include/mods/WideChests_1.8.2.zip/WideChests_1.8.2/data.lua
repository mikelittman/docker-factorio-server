if not MergingChests then MergingChests = {} end

require("prototypes.entity")
require("prototypes.item")
require("prototypes.recipe")