data:extend(
{
	{
		name = "max-chest-size",
		type = "int-setting",
		setting_type = "startup",
		minimum_value = 2,
		maximum_value = 42,
		default_value = 42,
		per_user = false,
		order = "1"
	},
	{
		name = "inventory-size-multiplier",
		type = "double-setting",
		setting_type = "startup",
		minimum_value = 0,
		default_value = 1.0,
		per_user = false,
		order = "2"
	},
	{
		name = "inventory-size-limit",
		type = "int-setting",
		setting_type = "startup",
		minimum_value = 1,
		default_value = 2016,
		per_user = false,
		order = "3"
	},
	{
		name = "ghost-timeout-minutes",
		type = "int-setting",
		setting_type = "startup",
		minimum_value = 1,
		default_value = 5,
		per_user = false,
		order = "4"
	},
})


